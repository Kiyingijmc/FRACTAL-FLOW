"""Domain package initialization."""
