"""Execution package initialization."""
