"""Persistence package initialization."""
