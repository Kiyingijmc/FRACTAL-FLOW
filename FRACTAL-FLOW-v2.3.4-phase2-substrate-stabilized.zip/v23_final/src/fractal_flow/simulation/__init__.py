"""Simulation package initialization."""
