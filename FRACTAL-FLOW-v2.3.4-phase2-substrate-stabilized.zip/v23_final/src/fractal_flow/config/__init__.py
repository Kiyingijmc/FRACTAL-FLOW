"""Config package initialization."""
